$(function () {
    var notes = JSON.parse(localStorage.getItem('notes')) || [];
    var tags = JSON.parse(localStorage.getItem('tags')) || [];

    $("#add_tag_btn").click(function () {
        let add_tag_text = $("#add_tag_text").val();
        console.log(tags);
        if (tags.includes(add_tag_text)) {
            alert("重複了!");
        }
        else {
            tags.push(add_tag_text);
        }
    })
})